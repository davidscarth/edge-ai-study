#!/bin/bash
set -e
mkdir -p /boot/efi/EFI/UpdateCapsule
cp $1 /boot/efi/EFI/UpdateCapsule
printf '\x04\x00\x00\x00\x00\x00\x00\x00' > set_cap_flag.bin
efivar --print --name 8be4df61-93ca-11d2-aa0d-00e098032b8c-OsIndications
efivar -w --name "8be4df61-93ca-11d2-aa0d-00e098032b8c-OsIndications" -f set_cap_flag.bin
efivar --print --name 8be4df61-93ca-11d2-aa0d-00e098032b8c-OsIndications
reboot